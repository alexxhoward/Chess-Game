# Board Duel iOS

This is a native iPhone wrapper for the Board Duel chess/backgammon game.

## Run on iPhone

1. Open `BoardDuel.xcodeproj` on a Mac with Xcode.
2. Select the `BoardDuel` target.
3. In **Signing & Capabilities**, choose your Apple Developer team.
4. Change the bundle identifier from `com.example.boardduel` if Xcode asks.
5. Connect your iPhone, choose it as the run destination, then press **Run**.

The app loads `iphone-board-duel.html` from the app bundle, so it works offline.
