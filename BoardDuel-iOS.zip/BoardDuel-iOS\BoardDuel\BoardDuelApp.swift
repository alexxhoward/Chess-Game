import SwiftUI

@main
struct BoardDuelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
